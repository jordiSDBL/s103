package n1ex1;

import java.util.ArrayList;

public class Test {
	public static void main(String[] args) {
		// VARIABLES
		ArrayList<Month> mesos = new ArrayList<Month>();
		Month mes1 = new Month("gener");
		Month mes2 = new Month("febrer");
		Month mes3 = new Month("mar�");
		Month mes4 = new Month("abril");
		Month mes5 = new Month("maig");
		Month mes6 = new Month("juny");
		Month mes7 = new Month("juliol");
		Month mes8 = new Month("agost");
		Month mes9 = new Month("setembre");
		Month mes10 = new Month("octubre");
		Month mes11 = new Month("novembre");
		Month mes12 = new Month("desembre");

		// afegim objectes tipus Month a l'arraylist (excepte el que t� atribut "agost")
		mesos.add(mes1);
		mesos.add(mes2);
		mesos.add(mes3);
		mesos.add(mes4);
		mesos.add(mes5);
		mesos.add(mes6);
		mesos.add(mes7);
		mesos.add(mes9);
		mesos.add(mes10);
		mesos.add(mes11);
		mesos.add(mes12);

		// comprovem el contingut de l'ArrayList
		System.out.println("SENSE el mes d'agost:");
		for (Month mes : mesos) {
			System.out.println(mes);
		}

		// afegim element nou de tipus Month
		mesos.add(7, mes8);

		// tornem a comprovar el contingut de l'ArrayList
		System.out.println("\nAMB el mes d'agost:");
		for (Month mes : mesos) {
			System.out.println(mes);
		}
	}
}
