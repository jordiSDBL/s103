package n1ex2;

public class Month {
	String name;

	public Month(String name) {
		this.name = name;
	}

	@Override
	public String toString() {
		return this.name;
	}
}
