package n1ex2;

import java.util.*;

public class Test {
	public static void main(String[] args) {
		// VARIABLES
		ArrayList<Month> mesos = new ArrayList<Month>();
		Month mes1 = new Month("gener");
		Month mes2 = new Month("febrer");
		Month mes3 = new Month("mar�");
		Month mes4 = new Month("abril");
		Month mes5 = new Month("maig");
		Month mes6 = new Month("juny");
		Month mes7 = new Month("juliol");
		Month mes8 = new Month("agost");
		Month mes9 = new Month("setembre");
		Month mes10 = new Month("octubre");
		Month mes11 = new Month("novembre");
		Month mes12 = new Month("desembre");

		// afegim objectes tipus Month a l'arraylist (excepte el que t� atribut "agost")
		mesos.add(mes1);
		mesos.add(mes2);
		mesos.add(mes3);
		mesos.add(mes4);
		mesos.add(mes5);
		mesos.add(mes6);
		mesos.add(mes7);
		mesos.add(mes9);
		mesos.add(mes10);
		mesos.add(mes11);
		mesos.add(mes12);

		// afegim element nou de tipus Month
		mesos.add(7, mes8);

		/**
		 * Canvis espec�fics exercici 2
		 */

		// creem un HashSet i hi passem l'ArrayList pel constructor per emplenar-lo amb les seves dades
		HashSet<Month> mesosUnics = new HashSet<Month>(mesos);

		// provem d'afegir objects que ja hi s�n
		mesosUnics.add(mes1);
		mesosUnics.add(mes8);
		mesosUnics.add(mes11);

		// imprimim el HashSet per veure que no s'hi han inclos els repetits
		for (Month month : mesosUnics) {
			System.out.println(month);
		}
	}
}
