package n1ex3;

import java.util.Collection;

public class Generadora<T extends Collection<String>> {
	// atribut de classe
	T llistat;
	static String[] personatges = { "Dolores Abernathy", "Maeve Millay", "Bernard Lowe", "Dr. Robert Ford",
			"Teddy Flood", "Charlotte Hale", "Caleb Nichols" };

	// constructor
	public Generadora(T llistat) {
		this.llistat = llistat;
	}

	private int index = 0;

	public String seguentPersonatge() {
		if (index > personatges.length - 1) {
			index = 0;
		}
		return personatges[index++];
	}

}
