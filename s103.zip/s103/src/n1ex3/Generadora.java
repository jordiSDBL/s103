package n1ex3;

import java.util.Collection;

public class Generadora<T extends Collection<String>> {
	// atributs
	T llistat;
	private int index = 0;
	public String[] personatges = { "Dolores Abernathy", "Maeve Millay", "Bernard Lowe", "Dr. Robert Ford",
			"Teddy Flood", "Charlotte Hale", "Caleb Nichols" };

	// constructor
	public Generadora(T llistat) {
		this.llistat = llistat;
	}

	/**
	 * M�tode amb que a cada crida, imprimir� un valor i i el proper cop imprimir�
	 * el seg�ent de la llista
	 * 
	 * @return String
	 */
	public String seguentPersonatge() {
		if (index > personatges.length - 1) {
			index = 0; // si s'arriba al final, tornar a al primera posici�
		}
		return personatges[index++];
	}
}
