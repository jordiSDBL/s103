package n1ex3;

import java.util.*;

public class Test {

	public static void main(String[] args) {
		// emplenem primer un contenidor amb diversos noms
		ArrayList<String> personatges = new ArrayList<String>();
		personatges.add("Dolores Abernathy");
		personatges.add("Maeve Millay");
		personatges.add("Bernard Lowe");
		personatges.add("Dr. Robert Ford");
		personatges.add("Teddy Flood");
		personatges.add("Charlotte Hale");
		personatges.add("Caleb Nichols");
		
		// creem la classe per rec�rrer l'array amb els noms
		Iterator<String> generadora = personatges.iterator();
		
		// creem tots els tipus de contenidors que es demanen
		ArrayList<String> al = new ArrayList<String>();
		LinkedList<String> ll = new LinkedList<String>();
		HashSet<String> hs = new HashSet<String>();
		LinkedHashSet<String> lhs = new LinkedHashSet<String>();
		TreeSet<String> ts = new TreeSet<String>();
		
		// recorrem tots els noms i els anem desant dins de cada contenidor
		while (generadora.hasNext()) {
			String cadena = generadora.next();
			al.add(cadena);
			ll.add(cadena);
			hs.add(cadena);
			lhs.add(cadena);
			ts.add(cadena);
			System.out.println(cadena);
		}
		// en acabar tornem l'iterador a la posici� inicial
		generadora = personatges.iterator();
		
		// imprimim tots els contenidors amb el m�tode imprimir()
		System.out.println("\nArrayList:");
		imprimir(al);
		System.out.println("\nLinkedList:");
		imprimir(ll);
		System.out.println("\nHashSet:");
		imprimir(hs);
		System.out.println("\nLinkedHashSet:");
		imprimir(lhs);
		System.out.println("\nTreeSet:");
		imprimir(ts);
		
		/**
		 * PREGUNTES DE L'EXERCICI A RESPONDRE:
		 * 
		 * QUINS CONTENIDORS PERMETEN ELEMENTS REPETITS? Els elements repetits nom�s es
		 * permeten en les classes que implementen la interf�cie List<E>, �s a dir,
		 * ArrayList i LinkedList. Les que implementen de la interf�cie Set<E>, la
		 * resta, no permeten elements repetits.
		 *
		 * QUINS CONTENIDORS PERMETEN UNA ORDENACI� PER ORDRE NATURAL O ALFANUM�RIC?
		 * ArrayList i LinkedList poden fer servir el m�tode de Collections.sort(List<T>
		 * list) i per tant es poden endre�ar alfab�ticament.
		 * HashSet no permet l'ordenaci�.
		 * A TreeSet, independentment de l'ordre d'agregarci� d'element, ja els emmagatzema
		 * ordenats.
		 * I LinkHashSet mant� l'ordre d'agregaci�, per� no es pot endre�ar directament.
		 * 
		 */
	}

	/**
	 * M�tode per imprimir els diferents tipus de llistes
	 * 
	 * @param c
	 */
	public static void imprimir(Collection<String> c) {
		for (String str : c) {
			System.out.println(str.toString());
		}
	}
}
