package n1ex3;

import java.util.*;

public class Test {

	public static void main(String[] args) {
		// contenidor amb els diferent tipus de llistes que caldr� emplenar
		ArrayList<Collection<String>> contenidor = new ArrayList<Collection<String>>();
		contenidor.add(new ArrayList<String>());
		contenidor.add(new LinkedList<String>());
		contenidor.add(new HashSet<String>());
		contenidor.add(new LinkedHashSet<String>());
		contenidor.add(new TreeSet<String>());

		// instanciem Generadora
		Generadora<Collection<String>> generadora;

		// recorrem cada element del contenidor (cada tipus de llista)
		for (int i = 0; i < contenidor.size(); i++) {
			generadora = new Generadora<>(contenidor.get(i)); // la inicialitzem
			System.out.println(contenidor.get(i).getClass().descriptorString().substring(11,
					(contenidor.get(i).getClass().descriptorString()).length() - 1) + ":");
			// l'emplenem amb seguentPersonatge()
			int j = 0;
			while (j < Generadora.personatges.length) {
				generadora.llistat.add(generadora.seguentPersonatge());
				j++;
			}
			imprimir(generadora.llistat); // l'enviem a imprimir
		}

		/**
		 * PREGUNTES DE L'EXERCICI A RESPONDRE:
		 * 
		 * QUINS CONTENIDORS PERMETEN ELEMENTS REPETITS? Els elements repetits nom�s es
		 * permeten en les classes que implementen la interf�cie List<E>, �s a dir,
		 * ArrayList i LinkedList. Les que implementen de la interf�cie Set<E>, la
		 * resta, no permeten elements repetits.
		 *
		 * QUINS CONTENIDORS PERMETEN UNA ORDENACI� PER ORDRE NATURAL O ALFANUM�RIC?
		 * ArrayList i LinkedList poden fer servir el m�tode de Collections.sort(List<T>
		 * list) i per tant es poden endre�ar alfab�ticament. HashSet no permet
		 * l'ordenaci�. A TreeSet, independentment de l'ordre d'agregarci� d'element, ja
		 * els emmagatzema ordenats. I LinkHashSet mant� l'ordre d'agregaci�, per� no es
		 * pot endre�ar directament.
		 * 
		 */
	}

	/**
	 * M�tode per imprimir els diferents tipus de llistes
	 * 
	 * @param c
	 */
	public static void imprimir(Collection<String> c) {
		for (String str : c) {
			System.out.println(str.toString());
		}
		System.out.println();
	}

}
