package n1ex4;

import java.util.*;

public class Test {
	public static void main(String[] args) {
		// creem i emplenem diversos tipus de col�leccions
		ArrayList<String> noms = new ArrayList<String>();
		noms.add("Pau");
		noms.add("Marc");
		noms.add("Am�lia");

		LinkedList<Integer> nombres = new LinkedList<Integer>();
		nombres.add(5);
		nombres.add(2);
		nombres.add(9);

		HashSet<Character> hs = new HashSet<Character>();
		hs.add('c');
		hs.add('p');
		hs.add('x');

		LinkedHashSet<Vehicle> vehicles = new LinkedHashSet<Vehicle>();
		vehicles.add(new Vehicle("Seat", 5, "Vermell"));
		vehicles.add(new Vehicle("Renault", 4, "Groc"));
		vehicles.add(new Vehicle("Jeep", 5, "Verd"));

		TreeSet<String> llenguatges = new TreeSet<String>();
		llenguatges.add("java");
		llenguatges.add("php");
		llenguatges.add("javascript");

		// cridem al m�tode per imprimir els contiguts
		iterCollection(noms);
		iterCollection(nombres);
		iterCollection(hs);
		iterCollection(vehicles);
		iterCollection(llenguatges);
	}

	/**
	 * M�tode per amb un iterador recorre la col�lecci� gen�rica i n'hi imprimeix
	 * els continguts.
	 * 
	 * @param <T>
	 * @param c
	 */
	public static <T> void iterCollection(Collection<T> c) {
		for (Iterator<T> iterator = c.iterator(); iterator.hasNext();) {
			T t = (T) iterator.next();
			System.out.println(t.toString());
		}
		System.out.println();
	}
}
