package n1ex4;

public class Vehicle {
	private String marca;
	private int portes;
	private String color;

	public Vehicle(String marca, int portes, String color) {
		this.marca = marca;
		this.portes = portes;
		this.color = color;
	}

	@Override
	public String toString() {
		return this.marca + ", " + this.portes + " portes, " + this.color + ".";
	}

}
