package n1ex5;

import java.util.*;

public class Test {
	public static void main(String[] args) {

		// creem la primera llista i hi posem objectes
		List<Integer> list1 = new ArrayList<Integer>();
		list1.add(3);
		list1.add(46);
		list1.add(17);
		list1.add(9);

		// creem la segona llista de la mida de la primera
		List<Integer> list2 = new ArrayList<Integer>(Collections.nCopies(list1.size(), null));

		// creem un ListIterator per cada llista
		ListIterator<Integer> it1 = list1.listIterator();
		ListIterator<Integer> it2 = list2.listIterator();

		
		// col�loquem el l'iterador de la segona llista en �ltima posici�
		while (it2.hasNext()) {
			it2.next();
		}
		// anem substituint els valors de la primera a la segona d'enrere a endavant
		while (it1.hasNext()) {
			it2.previous();
			it2.set(it1.next());
		}
		

		/**
		 * Manera alternativa
		 *
		 * Primer col�loquem l'iterador de la primera llista en �ltima posici�
		 * i despr�s anem avan�ant en la segona llista i sustituint els valors amb la primera
		 * la qual recorrem de final a principi 
		 * 
		while (it1.hasNext()) {
			it1.next();
		}
		while (it1.hasPrevious()) {
			it2.next();
			it2.set(it1.previous());
		}
		*/
		
		/**
		 * Manera alternativa2
		 *
		 * Si la segona llista estigu�s buida, es podria les mateixes dues versions anteriors
		 * per� amb el m�tode add()
		 * 
		 * 
		while (it1.hasNext()) {
			it1.next();
		}
		while (it1.hasPrevious()) {
			it2.next();
			it2.add(it1.previous());
		}
		*/
		
		/**
		 * Manera alternativa3
		 * 
		 * Amb un primer for emplenem la list2 agafant el valors recorreguts a l'inversa
		 * de la list1
		 * Amb un segon for i el m�tode removeIf, esborrem els null inicials per haver assignat una
		 * mida inicial a list2.
		 *
		for (int i = 0; i < list1.size(); i++) {
			list2.add(list1.get(list1.size()-i-1));
		}
		
		for (int i = 0; i < list2.size(); i++) {
			list2.removeIf(n -> (n == null));
		}
		*/

		// comprovem resultats
		System.out.println("Contingut de la list1:");
		System.out.println(list1);
		System.out.println();
		System.out.println("Contingut de la list2:");
		System.out.println(list2);

	}
}
