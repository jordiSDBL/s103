package n1ex6;

import java.util.*;

public class Test {
	public static void main(String[] args) {
		// inicialitzem el linkedlist que ens demanen i hi posem alguns valors
		LinkedList<Integer> enters = new LinkedList<Integer>();
		enters.add(5);
		enters.add(12);
		enters.add(3);
		enters.add(84);
		enters.add(100);
		enters.add(9);

		// declarem i inicialitzem l'iterador
		ListIterator<Integer> it = enters.listIterator();

		// cridem diverses vegades el m�tode per comprovar que funciona
		afegirValors(enters, it, 11111);
		System.out.println(enters);
		afegirValors(enters, it, 22222);
		System.out.println(enters);
		afegirValors(enters, it, 33333);
		System.out.println(enters);

	}

	/**
	 * M�tode per afegir enters a llistes a la posici� del mig
	 * 
	 * @param llista
	 * @param it
	 * @param valor
	 */
	public static void afegirValors(LinkedList<Integer> llista, ListIterator<Integer> it, int valor) {
		// inicialitzem l'iterador cada vegada
		it = llista.listIterator();
		// avancem l'iterador tantes posicions com la meitat de la mida de l'array
		int i = 0;
		while (i < (llista.size() / 2)) {
			it.next();
			i++;
		}
		it.add(valor); // a on s'atura, afegim el n�mero
	}
}
