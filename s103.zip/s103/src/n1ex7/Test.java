package n1ex7;

import java.util.*;

public class Test {
	public static void main(String[] args) {
		// col�leccions que farem servir
		LinkedHashMap<String, Integer> lhm = new LinkedHashMap<String, Integer>();
		LinkedHashSet<String> lhs = new LinkedHashSet<String>();
		HashSet<String> hs = new HashSet<String>();
		HashMap<String, Integer> mapa = new HashMap<String, Integer>();

		// emplenem el HashMap que ens demana l'enunciat
		mapa.put("mel�", 25);
		mapa.put("col", 453);
		mapa.put("oli", 113);
		mapa.put("sucre", 789);
		mapa.put("llet", 194);

		// n'imprimim el contingut recorrent-la i veiem que l'ordre ser� per codi hash
		System.out.println("Resultats del mapa. NO endre�ats:");
		for (String i : mapa.keySet()) {
			System.out.println("key: " + i + ", value: " + mapa.get(i));
		}
		
		// creem un tremap i hi posem tot el contingut del mapa
		TreeMap<String, Integer> treemap = new TreeMap<>();
		treemap.putAll(mapa);
		// comprovem que els treemap endrecen autom�ticament per clau
		System.out.println("\nOrdenaci� dins del treemap: ");
		for (String key : treemap.keySet()) {
			System.out.println("Clave: " + key + ", Valor: " + treemap.get(key));
			lhs.add(key); // afegim les claus al LinkedHashSet
			hs.add(key); // afegim les claus al HashSet
			lhm.put(key, treemap.get(key));// afegim les parelles al LinkedHashMap
		}

		// comprovem que el LinkedHashMap ara ja est� endre�at
		System.out.println("\nEl LinkedHashMap endre�at:");
		for (String i : lhm.keySet()) {
			System.out.println("key: " + i + ", value: " + lhm.get(i));
		}

		/*
		 * comprovem que el LinkedHashSet tamb� est� endre�at ja que els linked mantenen
		 * l'ordre d'inserci�
		 */
		System.out.println("\nEl LinkedHashSet amb les claus endre�at:");
		for (String string : lhs) {
			System.out.println(string);
		}

		// comprovem que el HashSet no est� endre�at, ja que aquest tipus no ho permet
		System.out.println("\nEl HashSet amb les claus NO endre�at:");
		for (String string : hs) {
			System.out.println(string);
		}

	}
}
