package n1ex8;

import java.util.*;

public class Test {
	public static void main(String[] args) {
		// creem el linkedhashmap
		LinkedHashMap<String, Integer> mapa = new LinkedHashMap<String, Integer>();
		mapa.put("Marcos", 32);
		mapa.put("Laia", 37);
		mapa.put("Llu�s", 23);
		mapa.put("Carme", 42);
		mapa.put("Nil", 28);
		
		// ordenaci� original del mapa, per ordre d'inserci� de dades
		System.out.println("Ordenaci� original del mapa: ");
		for (String i : mapa.keySet()) {
			System.out.println("key: " + i + ", value: " + mapa.get(i));
		}
		System.out.println();

		// creem un tremap i hi posem tot el contingut del mapa
		TreeMap<String, Integer> treemap = new TreeMap<>();
		treemap.putAll(mapa);
		// comprovem que els treemap endrecen autom�ticament per clau
		System.out.println("Ordenaci� dins del treemap: ");
		for (String key : treemap.keySet()) {
			System.out.println("Clave: " + key + ", Valor: " + treemap.get(key));
		}

		// esborrem els continguts que ten�em al mapa
		mapa.clear();
		/* i recorrent el treemap que est� en ordre passem les parelles al mapa i com
		 * que els linkedhashmap respecte l'ordre d'agregaci�, ja estar� endre�at tamb�.
		 */
		for (String key : treemap.keySet()) {
			mapa.put(key, treemap.get(key));
		}
		
		// comprovem que el linkedhashset ara ja est� endre�at
		System.out.println("\nEl mapa endre�at per les claus:");
		for (String i : mapa.keySet()) {
			System.out.println("key: " + i + ", value: " + mapa.get(i));
		}
	}
}
